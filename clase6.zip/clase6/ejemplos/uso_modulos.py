

def uno():
	print("dentrodel modulo")
	
from funciones import *

uno()

