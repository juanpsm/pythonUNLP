

def uno():
    print("uno")

print("HOOOOOOOOLLLLLLAAAA")

def dos():
    print("dos")


def tres():
    print("tres")


