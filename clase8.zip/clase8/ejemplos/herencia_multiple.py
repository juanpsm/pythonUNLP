class Jugador:
	def __init__(self, nombre, juego="Tetris", tiene_equipo= False, equipo=None):
		self.nombre = nombre
		self.juego = juego
		self.tiene_equipo = tiene_equipo
		self.equipo = equipo
		
	def jugar(self): 
		if self.tiene_equipo:
			print ("{} juega en equipo al {}".format(self.nombre, self.juego))
		else:
			print("{} juega solo al {}".format(self.nombre, self.juego))

class Deportista:
	def __init__(self, nombre, equipo = "Racing"):
		self.nombre = nombre
		self.equipo = equipo
		 
	def jugar(self): 
		print ("Mi equipo es {}".format(self.equipo))
			
class JugadorDeFIFA19(Jugador, Deportista):
	def __init__(self, nombre):
		Jugador.__init__(self, nombre, "PS4")
		Deportista.__init__(self,nombre)
		
class JugadorDeLOL(Deportista, Jugador):
	def __init__(self, nombre, equipo):
		Jugador.__init__(self, nombre, "LOL")
		Deportista.__init__(self, nombre, equipo)
			
nico = JugadorDeFIFA19('Nico Villalba')
nico.jugar()
faker = JugadorDeLOL("Faker", "SK Telecom")
faker.jugar()
