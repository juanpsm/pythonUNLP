class Jugador:
	def __init__(self, nom="Tony", nic="Ironman", clave="123", e_mail=""):
		self.nombre = nom
		self.nick = nic
		self.__contraseña = clave
		self.__mail = e_mail
		self.__vidas = 0
		self.__puntaje = 0	

		
	def __lt__(self, otro):
		return (self.nombre < otro.nombre)	
		
	def __eq__(self, otro):
		return (self.nick == otro.nick)	
		
	def __ne__(self, otro):
		return (self.nombre != otro.nombre)	
		
tony = Jugador()
bruce = Jugador("Bruce", "Batman")

print(tony)

print(tony < bruce)

print(tony if tony == bruce else bruce)
