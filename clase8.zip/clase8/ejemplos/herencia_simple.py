class Jugador:
	def __init__(self, nombre, juego="Tetris", tiene_equipo= False, equipo=None):
		self.nombre = nombre
		self.juego = juego
		self.tiene_equipo = tiene_equipo
		self.equipo = equipo
	def __str__(self):
		return ("sr."+self.nombre)	
	def jugar(self): 
		if self.tiene_equipo:
			print ("{} juega en equipo al {}".format(self.nombre, self.juego))
		else:
			print("{} juega solo al {}".format(self.nombre, self.juego))

class JugadorDeFIFA19(Jugador):
	def __init__(self, nombre):
		super().__init__(nombre, "PS4")
		
class JugadorDeLOL(Jugador):
	def __init__(self, nombre, equipo):
		Jugador.__init__(self, nombre, "LOL")
			
nico = JugadorDeFIFA19('Nico Villalba')
nico.jugar()


faker = JugadorDeLOL("Faker", "SK Telecom")
faker.jugar()
